# Resource specifications

## Topologies

### RocketFuel ISP latency maps

+------+---------------------+-------+--------+-------+-------------------+
| ASN  | Name                | Span  | Region | Nodes | Lrgst conn. comp. |
+======+=====================+=======+========+=======+===================+
| 1221 | Telstra (Australia) | world | AUS    |  108  |        104        |
| 1239 | Sprintlink (US)     | world | US     |  315  |        315        |
| 1755 | EBONE (Europe)      | world | Europe |   87  |         87        |
| 3257 | Tiscali (Europe)    | world | Europe |  161  |        161        |
| 3967 | Exodus (US)         | world | US     |   79  |         79        |
| 6461 | Abovenet (US)       | world | US     |  141  |        138        |
+------+---------------------+-------+--------+-------+-------------------+
